#include <permutation.h>
#include <sponge.h>
#include <string.h>

void sponge_init(sponge_t *sponge) {
  // TODO: fill the rest of this function.
  memset(sponge->state, 0, SPONGE_STATE_SIZE);
}

void sponge_read(uint8_t *dest, sponge_t const *sponge, uint64_t num) {
  // TODO: fill the rest of this function.
  memcpy(dest, sponge->state, num);
}

void sponge_write(sponge_t *sponge, uint8_t const *src, uint64_t num,
                  bool bw_xor) {
  // TODO: fill the rest of this function.
  // You may use the ^ operator to calculate a bit-wise XOR.
  if (bw_xor) {
    for (uint64_t i = 0; i < num; i++) {
      sponge->state[i] ^= src[i];
    }
  } else {
    memcpy(sponge->state, src, num);
  }
}

void sponge_demarcate(sponge_t *sponge, uint64_t i, uint8_t delimiter) {
  // TODO: fill the rest of this function.
  sponge->state[i] ^= delimiter;
}

void sponge_permute(sponge_t *sponge) {
  // TODO: fill the rest of this function.
  permute_384(sponge->state);
}
