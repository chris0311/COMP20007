#include <crypto.h>
#include <sponge.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// The sponge's rate, in bytes. This represents the maximum number of bytes
// which can be read from or written the start of the sponge's state before a
// permutation must occur.
#define RATE 16
// Delimiter byte value used after absorption of the message
#define DELIMITER_A 0xAD
// Delimiter byte used at the end of the last-used block
#define DELIMITER_B 0X77

// Helpful min function that might be useful.
uint64_t min(uint64_t a, uint64_t b) { return a < b ? a : b; }

// Solution implementation based on:
// https://gimli.cr.yp.to/gimli-20170627.pdf
// Appendix B
void hash(uint8_t *output, uint64_t output_len, uint8_t const *msg,
          uint64_t msg_len) {
  sponge_t sponge;
  sponge_init(&sponge);

  // TODO: fill the rest of this function.
  // Here are some examples of what sponge routines are called for various
  // invocations of this hash function:
  // hash(o, 5, m, 0) performs:
  //   sponge_write(&sponge, m, 0, true);
  //   sponge_demarcate(&sponge, 0, DELIMITER_A);
  //   sponge_demarcate(&sponge, RATE - 1, DELIMITER_B);
  //   sponge_permute(&sponge);
  //   sponge_read(o, &sponge, 5);
  //
  // hash(o, 16, m, 7) performs:
  //   sponge_write(&sponge, m, 7, true);
  //   sponge_demarcate(&sponge, 7, DELIMITER_A);
  //   sponge_demarcate(&sponge, RATE - 1, DELIMITER_B);
  //   sponge_permute(&sponge);
  //   sponge_read(o, &sponge, 16);
  //
  // hash(o, 23, m, 16) performs:
  //   sponge_write(&sponge, m, RATE, true);
  //   sponge_permute(&sponge);
  //   sponge_write(&sponge, m + RATE, 0, true);
  //   sponge_demarcate(&sponge, 0, DELIMITER_A);
  //   sponge_demarcate(&sponge, RATE - 1, DELIMITER_B);
  //   sponge_permute(&sponge);
  //   sponge_read(o, &sponge, RATE);
  //   sponge_permute(&sponge);
  //   sponge_read(o + RATE, &sponge, 7);
  //
  // hash(o, 32, m, 23) performs:
  //   sponge_write(&sponge, m, RATE, true);
  //   sponge_permute(&sponge);
  //   sponge_write(&sponge, m + RATE, 7, true);
  //   sponge_demarcate(&sponge, 7, DELIMITER_A);
  //   sponge_demarcate(&sponge, RATE - 1, DELIMITER_B);
  //   sponge_permute(&sponge);
  //   sponge_read(o, &sponge, RATE);
  //   sponge_permute(&sponge);
  //   sponge_read(o + RATE, &sponge, 16);
  uint64_t block_size = 0;
  while (msg_len > 0) {
    block_size = min(msg_len, RATE);
    sponge_write(&sponge, msg, block_size, true);
    msg += block_size;
    msg_len -= block_size;

    if (block_size == RATE) {
      sponge_permute(&sponge);
      block_size = 0;
    }
  }

  sponge_demarcate(&sponge, block_size, DELIMITER_A);
  sponge_demarcate(&sponge, RATE - 1, DELIMITER_B);
  sponge_permute(&sponge);

  while (output_len > 0) {
    block_size = min(output_len, RATE);
    sponge_read(output, &sponge, block_size);
    output += block_size;
    output_len -= block_size;

    if (output_len > 0) {
      sponge_permute(&sponge);
    }
  }
}

void mac(uint8_t *tag, uint64_t tag_len, uint8_t const *key, uint8_t const *msg,
         uint64_t msg_len) {
  sponge_t sponge;
  sponge_init(&sponge);

  // TODO: fill the rest of this function.
  // Your implementation should like very similar to that of the hash
  // function's, but should include a keying phase before the absorbing phase.
  // If you wish, you may also treat this as calculating the hash of the key
  // prepended to the message.
  uint64_t key_len = CRYPTO_KEY_SIZE;
  while (key_len > 0) {
    sponge_write(&sponge, key, RATE, true);
    key += RATE;
    key_len -= RATE;
    sponge_permute(&sponge);
  }

  uint64_t block_size = 0;
  while (msg_len > 0) {
    block_size = min(msg_len, RATE);
    sponge_write(&sponge, msg, block_size, true);
    msg += block_size;
    msg_len -= block_size;

    if (block_size == RATE) {
      sponge_permute(&sponge);
      block_size = 0;
    }
  }

  sponge_demarcate(&sponge, block_size, DELIMITER_A);
  sponge_demarcate(&sponge, RATE - 1, DELIMITER_B);
  sponge_permute(&sponge);

  while (tag_len > 0) {
    block_size = min(tag_len, RATE);
    sponge_read(tag, &sponge, block_size);
    tag += block_size;
    tag_len -= block_size;

    if (tag_len > 0) {
      sponge_permute(&sponge);
    }
  }
}

void auth_encr(uint8_t *ciphertext, uint8_t *tag, uint64_t tag_len,
               uint8_t const *key, uint8_t const *plaintext,
               uint64_t text_len) {
  sponge_t sponge;
  sponge_init(&sponge);

  // TODO: fill the rest of this function.
  // Your implementation should like very similar to that of the mac function's,
  // but should after each write into the sponge's state, there should
  // immediately follow a read from the sponge's state of the same number of
  // bytes, into the ciphertext buffer.
  uint64_t key_len = CRYPTO_KEY_SIZE;
  while (key_len > 0) {
    sponge_write(&sponge, key, RATE, true);
    key += RATE;
    key_len -= RATE;
    sponge_permute(&sponge);
  }

  uint64_t block_size = 0;
  while (text_len > 0) {
    block_size = min(text_len, RATE);
    sponge_write(&sponge, plaintext, block_size, true);
    sponge_read(ciphertext, &sponge, block_size);
    plaintext += block_size;
    ciphertext += block_size;
    text_len -= block_size;

    if (block_size == RATE) {
      sponge_permute(&sponge);
      block_size = 0;
    }
  }

  sponge_demarcate(&sponge, block_size, DELIMITER_A);
  sponge_demarcate(&sponge, RATE - 1, DELIMITER_B);
  sponge_permute(&sponge);

  while (tag_len > 0) {
    block_size = min(tag_len, RATE);
    sponge_read(tag, &sponge, block_size);
    tag += block_size;
    tag_len -= block_size;

    if (tag_len > 0) {
      sponge_permute(&sponge);
    }
  }
}

int auth_decr(uint8_t *plaintext, uint8_t const *key, uint8_t const *ciphertext,
              uint64_t text_len, uint8_t const *tag, uint64_t tag_len) {
  sponge_t sponge;
  sponge_init(&sponge);

  // TODO: fill the rest of this function.
  // The implementation of this function is left as a challenge. It may assist
  // you to know that a ^ b ^ b = a.
  uint64_t key_len = CRYPTO_KEY_SIZE;
  while (key_len > 0) {
    sponge_write(&sponge, key, RATE, true);
    key += RATE;
    key_len -= RATE;
    sponge_permute(&sponge);
  }

  uint64_t block_size = 0;
  while (text_len > 0) {
    block_size = min(text_len, RATE);
    sponge_write(&sponge, ciphertext, block_size, true);
    sponge_read(plaintext, &sponge, block_size);
    sponge_write(&sponge, ciphertext, block_size, false);
    plaintext += block_size;
    ciphertext += block_size;
    text_len -= block_size;

    if (block_size == RATE) {
      sponge_permute(&sponge);
      block_size = 0;
    }
  }

  sponge_demarcate(&sponge, block_size, DELIMITER_A);
  sponge_demarcate(&sponge, RATE - 1, DELIMITER_B);
  sponge_permute(&sponge);

  uint8_t *local_tag_start = malloc(tag_len * sizeof(uint8_t));
  if (local_tag_start == NULL) {
    return 1;
  }

  uint8_t *local_tag = local_tag_start;
  uint64_t local_tag_len = tag_len;
  while (local_tag_len > 0) {
    block_size = min(local_tag_len, RATE);
    sponge_read(local_tag, &sponge, block_size);
    local_tag += block_size;
    local_tag_len -= block_size;

    if (local_tag_len > 0) {
      sponge_permute(&sponge);
    }
  }

  int const res = memcmp(tag, local_tag_start, tag_len) == 0 ? 0 : 1;
  free(local_tag_start);

  return res;
}
