#ifndef __PERMUTATION_H__
#define __PERMUTATION_H__

#include <stdint.h>

// Applies an in-place bijective transformation to an input array of 384 bits.
void permute_384(uint8_t *state);

#endif
