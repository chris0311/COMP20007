/*
graph.c

Set of vertices and edges implementation.

Implementations for helper functions for graph construction and manipulation.

Skeleton written by Grady Fitzpatrick for COMP20007 Assignment 1 2022
*/
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include "graph.h"
#include "utils.h"
#include "pq.h"

#define INITIALEDGES 32
#define NOPATH (INT_MAX)
#define PQ_ADDED (1)
#define PQ_UNSEEN (0)
#define PQ_REMOVED (-1)

struct edge;

/* Definition of a graph. */
struct graph {
  int numVertices;
  int numEdges;
  int allocedEdges;
  struct edge **edgeList;
};

/* Definition of an edge. */
struct edge {
  int start;
  int end;
  int cost;
};

/* Apply a heart room to the given room. */
void applyHeartRoom(struct graph *g, int heartRoom);

/* Run Dijksta's algorithm on the given graph until the shortest path from the 
source node to the destination node is found. Returns the cost of the shortest
path. */
int dijkstra(struct graph *g, int vertices, int source, int destination);

struct graph *newGraph(int numVertices){
  struct graph *g = (struct graph *) malloc(sizeof(struct graph));
  assert(g);
  /* Initialise edges. */
  g->numVertices = numVertices;
  g->numEdges = 0;
  g->allocedEdges = 0;
  g->edgeList = NULL;
  return g;
}

/* Adds an edge to the given graph. */
void addEdge(struct graph *g, int start, int end, int cost){
  assert(g);
  struct edge *newEdge = NULL;
  /* Check we have enough space for the new edge. */
  if((g->numEdges + 1) > g->allocedEdges){
    if(g->allocedEdges == 0){
      g->allocedEdges = INITIALEDGES;
    } else {
      (g->allocedEdges) *= 2;
    }
    g->edgeList = (struct edge **) realloc(g->edgeList,
      sizeof(struct edge *) * g->allocedEdges);
    assert(g->edgeList);
  }

  /* Create the edge */
  newEdge = (struct edge *) malloc(sizeof(struct edge));
  assert(newEdge);
  newEdge->start = start;
  newEdge->end = end;
  newEdge->cost = cost;

  /* Add the edge to the list of edges. */
  g->edgeList[g->numEdges] = newEdge;
  (g->numEdges)++;
}

/* Returns a new graph which is a deep copy of the given graph (which must be 
  freed with freeGraph when no longer used). */
struct graph *duplicateGraph(struct graph *g){
  struct graph *copyGraph = (struct graph *) malloc(sizeof(struct graph));
  assert(copyGraph);
  copyGraph->numVertices = g->numVertices;
  copyGraph->numEdges = g->numEdges;
  copyGraph->allocedEdges = g->allocedEdges;
  copyGraph->edgeList = (struct edge **) malloc(sizeof(struct edge *) * g->allocedEdges);
  assert(copyGraph->edgeList || copyGraph->numEdges == 0);
  int i;
  /* Copy edge list. */
  for(i = 0; i < g->numEdges; i++){
    struct edge *newEdge = (struct edge *) malloc(sizeof(struct edge));
    assert(newEdge);
    newEdge->start = (g->edgeList)[i]->start;
    newEdge->end = (g->edgeList)[i]->end;
    newEdge->cost = (g->edgeList)[i]->cost;
    (copyGraph->edgeList)[i] = newEdge;
  }
  return copyGraph;
}

/* Frees all memory used by graph. */
void freeGraph(struct graph *g){
  int i;
  for(i = 0; i < g->numEdges; i++){
    free((g->edgeList)[i]);
  }
  if(g->edgeList){
    free(g->edgeList);
  }
  free(g);
}

void applyHeartRoom(struct graph *g, int heartRoom){
  int i;
  for(i = 0; i < g->numEdges; i++){
    if(g->edgeList[i]->end == heartRoom){
      /* Entering heart room is free. */
      g->edgeList[i]->cost = 0;
    }
  }
}

/* Run Dijksta's algorithm on the given graph until the shortest path from the 
source node to the destination node is found. Returns the cost of the shortest
path. */
int dijkstra(struct graph *g, int vertices, int source, int destination){
  /* Only need to know cost to destination, so don't need previous vertex, but useful for 
    debugging. */
  int *prev = NULL;

  /* The cost from the source to each destination. */
  int *cost = NULL;
  /* Whether the item is in the priority queue. */
  int *inpq = NULL;
  prev = (int *) malloc(sizeof(int) * vertices);
  assert(prev);
  cost = (int *) malloc(sizeof(int) * vertices);
  assert(cost);
  inpq = (int *) malloc(sizeof(int) * vertices);
  assert(inpq);
  int i;
  /* Initialise costs and inpq status. */
  for(i = 0; i < vertices; i++){
    prev[i] = NOPATH;
    cost[i] = NOPATH;
    inpq[i] = PQ_UNSEEN;
  }
  /* Source vertex cost is 0 */
  cost[source] = 0;
  struct pq *pq = newPQ();
  /* Insert source vertex. Store integer in void pointer and unpack later. */
  enqueue(pq, (void *) ((size_t)source), cost[source]);
  /* Mark the node as in the priority queue. */
  inpq[source] = PQ_ADDED;
  while(! empty(pq)){
    int next = (int)((size_t) deletemin(pq));
    if(inpq[next] == PQ_REMOVED){
      /* Already been removed from the priority queue, so this value is stale. */
      continue;
    } else {
      /* We've removed this item from the priority queue so it never needs to be added again. */
      inpq[next] = PQ_REMOVED;
      /* If item is destination, we're done, exploration order is strictly increasing so no 
        unexplored path can be cheaper. */
      if(next == destination){
        break;
      }
    }
    /* Process through edges - Operation would be more efficient with an adjacency list. */
    for(i = 0; i < g->numEdges; i++){
      if(g->edgeList[i] && g->edgeList[i]->start == next){
        if(cost[next] + g->edgeList[i]->cost < cost[g->edgeList[i]->end]){
          /* Found a cheaper route to g->edgeList[i]->end. */
          cost[g->edgeList[i]->end] = cost[next] + g->edgeList[i]->cost;
          prev[g->edgeList[i]->end] = next;
          inpq[g->edgeList[i]->end] = PQ_ADDED;
          /* Add to queue */
          enqueue(pq, (void *) ((size_t)(g->edgeList[i]->end)), cost[g->edgeList[i]->end]);
        }
      }
    }
  }
  int finalCost = cost[destination];
  /* Cleanup */
  free(cost);
  free(inpq);
  free(prev);
  freePQ(pq);
  return finalCost;
} 

struct solution *graphSolve(struct graph *g, enum problemPart part,
  int numRooms, int startingRoom, int bossRoom, int numShortcuts, 
  int *shortcutStarts, int *shortcutEnds, int numHeartRooms, int *heartRooms){
  int i;
  struct solution *solution = (struct solution *)
    malloc(sizeof(struct solution));
  assert(solution);
  if(part == PART_A){
    /* IMPLEMENT 2A SOLUTION HERE */
    solution->heartsLost = dijkstra(g, numRooms, startingRoom, bossRoom);
  } else if(part == PART_B) {
    /* IMPLEMENT 2B SOLUTION HERE */
    solution->heartsLost = dijkstra(g, numRooms, startingRoom, bossRoom);
    for(i = 0; i < numShortcuts; i++){
      struct graph *gShortcut = duplicateGraph(g);
      /* Run through, taking each shortcut. */
      addEdge(gShortcut, shortcutStarts[i], shortcutEnds[i], 1);
      addEdge(gShortcut, shortcutEnds[i], shortcutStarts[i], 1);
      int shortcutHearts = dijkstra(gShortcut, numRooms, startingRoom, bossRoom);
      if(shortcutHearts < solution->heartsLost){
        solution->heartsLost = shortcutHearts;
      }
      freeGraph(gShortcut);
    }
  } else {
    /* IMPLEMENT 2C SOLUTION HERE */
    for(i = 0; i < numHeartRooms; i++){
      applyHeartRoom(g, heartRooms[i]);
    }
    solution->heartsLost = dijkstra(g, numRooms, startingRoom, bossRoom);
  }
  return solution;
}

